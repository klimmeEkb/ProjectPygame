import os, os.path
import sys
import pygame


class AnimatedSprite(pygame.sprite.Sprite):
    def __init__(self, sheet, columns, rows, x, y, all_sprites):
        super().__init__(all_sprites)
        self.frames = []
        self.cut_sheet(sheet, columns, rows)
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]
        self.rect = self.rect.move(x, y)

    def cut_sheet(self, sheet, columns, rows):
        self.rect = pygame.Rect(0, 0, sheet.get_width() // columns, sheet.get_height() // rows)
        for j in range(rows):
            for i in range(columns):
                frame_location = (self.rect.w * i, self.rect.h * j)
                self.frames.append(sheet.subsurface(pygame.Rect(frame_location, self.rect.size)))

    def update(self):
        self.cur_frame = (self.cur_frame + 1) % len(self.frames)
        self.image = self.frames[self.cur_frame]


def load_image(name, colorkey=None):
	fullname = os.path.join('data', name)
	# если файл не существует, то выходим
	if not os.path.isfile(fullname):
		print(f"Файл с изображением '{fullname}' не найден")
		sys.exit()
	image = pygame.image.load(fullname)
	if colorkey is not None:
		image = image.convert()
		if colorkey == -1:
			colorkey = image.get_at((0, 0))
		image.set_colorkey(colorkey)
	else:
		image = image.convert_alpha()
	return image


class Start:
	def __init__(self):
		self.width = 17
		self.height = 17
		self.cell_size = 30
		self.x, self.y, self.z = 5, 5, 5
		self.sprite_group = pygame.sprite.Group()
		self.sprite = pygame.sprite.Sprite()
		self.sprite.image = load_image("nether.png")
		self.sprite.rect = self.sprite.image.get_rect()
		self.sprite_group.add(self.sprite)
		self.sprite.rect.x = 0
		self.sprite.rect.y = 0

	def draw(self, screen):
		font = pygame.font.Font(None, 100)
		text = font.render("A hot walk", True, (10, 10, 10))
		text_x = 70
		text_y = 10
		text_w = text.get_width()
		text_h = text.get_height()
		font_exit = pygame.font.Font(None, 100)
		text_exit = font_exit.render("exit", True, (10, 10, 10))
		text_exit_x = 190
		text_exit_y = 310
		text_exit_w = text.get_width()
		text_exit_h = text.get_height()
		screen.blit(text, (text_x, text_y))
		screen.blit(text_exit, (text_exit_x, text_exit_y))


	def get_cell(self, mouse_pos):
		x, y = mouse_pos
		if x in range(self.cell_size * self.width) and y in range(self.cell_size * self.height):
			return x // self.cell_size, y // self.cell_size
		return None

	def on_click(self, mouse_pos):
		cell = self.get_cell(mouse_pos)
		if cell:
			if cell[0] >= 0 and cell[1] >= 0:
				x, y = cell
				if x in range(4, 10) and y in range(5, 8):
					return True
	def exit_click(self, mouse_pos):
		cell = self.get_cell(mouse_pos)
		if cell:
			if cell[0] >= 0 and cell[1] >= 0:
				x, y = cell
				if x in range(4, 10) and y in range(10, 13):
					return True

	def render(self, surface, other, other_exit):
		self.surface = surface
		for i in range(17):
			for j in range(17):
				pygame.draw.rect(self.surface, (10, 10, 10), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size), 1)
		self.sprite_group.draw(self.surface)
		for i in range(5, 8):
			for j in range(6, 11):
				pygame.draw.rect(self.surface, (100, 10, 10), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size))
		for i in range(10, 13):
			for j in range(6, 11):
				pygame.draw.rect(self.surface, (100, 10, 10), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size))
		
		if other:
			for i in range(5, 8):
				for j in range(6, 11):
					pygame.draw.rect(self.surface, (100, 50, 50), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size))
		elif other_exit:
			for i in range(10, 13):
				for j in range(6, 11):
					pygame.draw.rect(self.surface, (100, 50, 50), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size))


class Board:
	def __init__(self):
		self.width = 10
		self.height = 10
		self.length = 10
		self.cell_size = 50
		self.mosx, self.mosy = 25, 25
		self.x, self.y, self.z = 5, 5, 5
		self.left, self.top = 9, 1
		self.sprite_group = pygame.sprite.Group()
		self.sprite = pygame.sprite.Sprite()
		self.sprite.image = load_image("void.png")
		self.sprite.rect = self.sprite.image.get_rect()
		self.sprite_group.add(self.sprite)
		self.sprite.rect.x = 0
		self.sprite.rect.y = 0

	def render(self, surface, krug):
		self.surface = surface
		self.krug = krug
		for i in range(16):
			for j in range(31):
				pygame.draw.rect(self.surface, (10, 10, 10), (j * self.cell_size, i * self.cell_size, self.cell_size, self.cell_size), 1)
		self.sprite_group.draw(self.surface)
		pygame.draw.rect(self.surface, (60, 10, 10), ((9 + krug) * self.cell_size, (1 + krug) * self.cell_size, (13 - 2 * krug) * self.cell_size, (13 - 2 * krug) * self.cell_size))

	def get_cell(self, mouse_pos):
		x, y = mouse_pos
		if x in range(self.cell_size * self.left + krug * self.cell_size, self.cell_size * self.left + krug * self.cell_size + (13 - krug) * self.cell_size) and y in range(self.cell_size * self.top + krug * self.cell_size, self.cell_size * self.top + krug * self.cell_size + (13 - krug) * self.cell_size):
			return x // self.cell_size, y // self.cell_size
		return None

	def on_click(self, cell_coords):
		pass

	def get_click(self, mouse_pos):
		cell = self.get_cell(mouse_pos)
		if cell:
			if cell[0] >= 0 and cell[1] >= 0:
				self.on_click(cell)


class End:
	def __init__(self, krug, hp):
		self.width = 17
		self.height = 17
		self.cell_size = 30
		self.hp = hp
		self.sprite_group = pygame.sprite.Group()
		self.sprite = pygame.sprite.Sprite()
		self.sprite.image = load_image("death.png")
		self.sprite.rect = self.sprite.image.get_rect()
		self.sprite_group.add(self.sprite)
		self.sprite.rect.x = 0
		self.sprite.rect.y = 0
		self.krug = krug
		self.flag_fire1 = False
		self.flag_fire2 = False
		self.flag_fire3 = False
		self.fires1, self.fires2, self.fires3 = None, None, None

	def draw(self, screen):
		font = pygame.font.Font(None, 200)
		text = font.render("Ты погиб", True, (100, 10, 10))
		text_x = 300
		text_y = 10
		text_w = text.get_width()
		text_h = text.get_height()
		font_exit = pygame.font.Font(None, 200)
		text_exit = font_exit.render(f"на {self.krug + 1} круге", True, (100, 10, 10))
		text_exit_x = 300
		text_exit_y = 500
		text_exit_w = text.get_width()
		text_exit_h = text.get_height()
		screen.blit(text, (text_x, text_y))
		screen.blit(text_exit, (text_exit_x, text_exit_y))

	def draw_true(self, screen):
		font = pygame.font.Font(None, 200)
		text = font.render("Ты сбежал!", True, (100, 10, 10))
		text_x = 250
		text_y = 10
		text_w = text.get_width()
		text_h = text.get_height()
		font_exit = pygame.font.Font(None, 200)
		if self.krug == 5:
			text_exit = font_exit.render("но какой ценой?", True, (100, 10, 10))
		else:
			text_exit = font_exit.render("но они позади", True, (100, 10, 10))
		text_exit_x = 200
		text_exit_y = 500
		text_exit_w = text.get_width()
		text_exit_h = text.get_height()
		screen.blit(text, (text_x, text_y))
		screen.blit(text_exit, (text_exit_x, text_exit_y))
		font_achievment = pygame.font.Font(None, 25)
		text_achievment = font_achievment.render(open("easter.txt", encoding="utf8").read()[:11], True, (255, 215, 0))
		text_achievment_x, text_achievment_y = 1000, 170
		if self.hp == 6:
			screen.blit(text_achievment, (text_achievment_x, text_achievment_y))

	def render(self, surface):
		self.surface = surface
		self.sprite_group.draw(self.surface)

	def fires(self, surface, coords, all_sprites):
		self.surface = surface
		x, y = coords
		if x in range(428, 506) and y in range(256, 311) and not self.flag_fire1:
			self.fires1 = AnimatedSprite(load_image("fires.png", colorkey=-1), 8, 6, 378, 76, all_sprites)
			self.flag_fire1 = True
		if x in range(572, 653) and y in range(257, 307) and not self.flag_fire2:
			self.fires2 = AnimatedSprite(load_image("fires.png", colorkey=-1), 8, 6, 528, 76, all_sprites)
			self.flag_fire2 = True
		if x in range(480, 606) and y in range(408, 478) and not self.flag_fire3:
			self.fires3 = AnimatedSprite(load_image("fires.png", colorkey=-1), 8, 6, 453, 261, all_sprites)
			self.flag_fire3 = True
		return self.fires1, self.fires2, self.fires3


class StartMenu:
	def __init__(self):
		self.TheGame = None
		self.need = False
		self.change = False
		self.change_exit = False
		pygame.init()
		pygame.display.set_caption('Добро пожаловать! :)')
		self.size = width, height = 510, 510
		self.screen = pygame.display.set_mode(self.size)
		self.start = Start()
		self.running = True
		pygame.mouse.set_visible(False)
		self.all_sprites = pygame.sprite.Group()
		self.sprite = pygame.sprite.Sprite()
		self.sprite.image = load_image("arrow.png", colorkey=-1)
		self.sprite.rect = self.sprite.image.get_rect()
		self.all_sprites.add(self.sprite)
		self.sprite.rect.x = 100
		self.sprite.rect.y = 100
		self.skulls = pygame.sprite.Group()
		self.skull = pygame.sprite.Sprite()
		self.skull.image = load_image("skull.png", colorkey=-1)
		self.skull.rect = self.skull.image.get_rect()
		self.skulls.add(self.skull)
		self.skull.rect.x = 210
		self.skull.rect.y = 150
		self.x, self.y = 0, 0

	def game(self):
		while self.running:
			key = pygame.key.get_pressed()
			self.screen.fill((0, 0, 0))
			for event in pygame.event.get():
				match event.type:
					case pygame.MOUSEBUTTONUP:
						if self.start.on_click(event.pos):
							self.need = True
							self.change = False
							self.running = False
						elif self.start.exit_click(event.pos):
							self.running = False
							self.change_exit = False
						else:
							self.change = False
							self.change_exit = False
					case pygame.MOUSEBUTTONDOWN:
						if self.start.on_click(event.pos):
							self.change = True
						elif self.start.exit_click(event.pos):
							self.change_exit = True
					case pygame.MOUSEMOTION:
						self.x, self.y = event.pos
					case pygame.QUIT:
						self.running = False
					case pygame.K_RETURN:
						self.need = True
						self.running = False
					case pygame.K_ESCAPE:
						self.running = False
			if key[pygame.K_RETURN]:
				self.need = True
				self.running = False
			elif key[pygame.K_ESCAPE]:
				self.running = False
			self.sprite.rect.x = self.x
			self.sprite.rect.y = self.y
			self.start.render(self.screen, self.change, self.change_exit)
			self.start.draw(self.screen)
			self.skulls.draw(self.screen)
			self.all_sprites.draw(self.screen)
			pygame.display.flip()
		pygame.quit()
		if self.need:
			self.TheGame = TheGame()
			self.TheGame.game()


class TheGame:
	def __init__(self):
		self.krug = 0
		pygame.init()
		pygame.display.set_caption('Проектная игра')
		self.size = width, height = 1550, 800
		self.screen = pygame.display.set_mode(self.size)
		self.board = Board()
		self.running = True
		pygame.mouse.set_visible(False)
		self.clock = pygame.time.Clock()
		self.hero_rectx = 10 * 50 + self.krug * 50
		self.hero_recty = 2 * 50 + self.krug * 50
		self.all_sprites = pygame.sprite.Group()
		self.sprite = pygame.sprite.Sprite()
		self.sprite.image = load_image("arrow.png", colorkey=-1)
		self.sprite.rect = self.sprite.image.get_rect()
		self.all_sprites.add(self.sprite)
		self.sprite.rect.x = 100
		self.sprite.rect.y = 100
		self.moving = False
		self.move_hero = True
		self.hero_sp = [load_image("hero_top.png", colorkey=-1), load_image("hero_left.png", colorkey=-1), load_image("hero_right.png", colorkey=-1), load_image("hero_back.png", colorkey=-1)]
		self.hero_chos = 0
		self.hp_kolvo = 6
		self.hp = load_image("hp.png", colorkey=-1)
		self.red_fon = load_image("red_fon.jpg")

	def game(self):
		while self.running:
			key = pygame.key.get_pressed()
			self.screen.fill((0, 0, 0))
			self.board.render(self.screen, self.krug)
			for event in pygame.event.get():
				match event.type:
					case pygame.MOUSEBUTTONDOWN:
						self.x, self.y = event.pos
						if (self.x in range(self.hero_rectx - 35, self.hero_rectx + 35) and self.y in range(self.hero_recty - 35, self.hero_recty + 35)):
							if self.krug != 3:
								self.moving = True
								self.move_hero = False
							else:
								self.hero_rectx = 10 * 50 + self.krug * 50
								self.hero_recty = 2 * 50 + self.krug * 50
								self.hp_kolvo -= 1
					case pygame.QUIT:
						self.running = False
					case pygame.MOUSEMOTION:
						if pygame.mouse.get_focused():
							self.x, self.y = event.pos
							if self.moving:
								self.xrel, self.yrel = event.rel
								self.hero_rectx += self.xrel
								self.hero_recty += self.yrel
					case pygame.MOUSEBUTTONUP:
						if self.moving:
							if (self.sprite.rect.x + 25 not in range(450 + self.krug * 50, 450 + self.krug * 50 + (13 - self.krug * 2) * 50) or self.sprite.rect.y + 25 not in range(50 + self.krug * 50, 50 + self.krug * 50 + (13 - self.krug * 2) * 50)):
								if self.krug != 4:
									self.hero_rectx = 10 * 50 + self.krug * 50
									self.hero_recty = 2 * 50 + self.krug * 50
									self.hp_kolvo -= 1
								else:
									self.krug += 1
									self.hero_rectx = 9 * 50 + self.krug * 50
									self.hero_recty = 50 + self.krug * 50
							elif self.krugy():
								self.krug += 1
							self.moving = False
							self.move_hero = True
			if self.move_hero:
				if key[pygame.K_DOWN] or key[pygame.K_s]:		
					if self.hero_recty + 25 in range(50 + self.krug * 50, 50 + self.krug * 50 + ((13 - self.krug * 2) * 50)):
						if self.krug == 1:
							self.hero_recty -= 5
						elif self.krug == 2:
							self.hp_kolvo -= 1
						else:
							self.hero_recty += 5
						if self.krugy():
							if self.krug != 4:
								self.krug += 1
							else:
								self.hero_rectx = 10 * 50 + self.krug * 50
								self.hero_recty = 2 * 50 + self.krug * 50
								self.hp_kolvo -= 1
						self.hero_chos = 0
				elif key[pygame.K_UP] or key[pygame.K_w]:
					if self.hero_recty + 25 in range(50 + self.krug * 50, 50 + self.krug * 50 + ((13 - self.krug * 2) * 50)):
						if self.krug == 1:
							self.hero_recty += 5
						elif self.krug == 2:
							self.hp_kolvo -= 1
						else:
							self.hero_recty -= 5
						if self.krugy():
							if self.krug != 4:
								self.krug += 1
							else:
								self.hero_rectx = 10 * 50 + self.krug * 50
								self.hero_recty = 2 * 50 + self.krug * 50
								self.hp_kolvo -= 1
						self.hero_chos = 3
				elif key[pygame.K_RIGHT] or key[pygame.K_d]:
					if self.hero_rectx + 25 in range(450 + self.krug * 50, 450 + self.krug * 50 + (13 - self.krug * 2) * 50):
						if self.krug == 1:
							self.hero_rectx -= 5
						elif self.krug == 2:
							self.hp_kolvo -= 1
						else:
							self.hero_rectx += 5
						if self.krugy():
							if self.krug != 4:
								self.krug += 1
							else:
								self.hero_rectx = 10 * 50 + self.krug * 50
								self.hero_recty = 2 * 50 + self.krug * 50
								self.hp_kolvo -= 1
						self.hero_chos = 2
				elif key[pygame.K_LEFT] or key[pygame.K_a]:
					if self.hero_rectx + 25 in range(450 + self.krug * 50, 450 + self.krug * 50 + (13 - self.krug * 2) * 50):
						if self.krug == 1:
							self.hero_rectx += 5
						elif self.krug == 2:
							self.hp_kolvo -= 1
						else:
							self.hero_rectx -= 5
						if self.krugy():
							if self.krug != 4:
								self.krug += 1
							else:
								self.hero_rectx = 10 * 50 + self.krug * 50
								self.hero_recty = 2 * 50 + self.krug * 50
								self.hp_kolvo -= 1
						self.hero_chos = 1
			elif key[pygame.K_ESCAPE]:
				self.running = False
			self.sprite.rect.x = self.x
			self.sprite.rect.y = self.y
			self.screen.blit(pygame.transform.scale(self.red_fon, ((13 - self.krug * 2) * 50, (13 - self.krug * 2) * 50)), (450 + self.krug * 50, 50  + self.krug * 50))
			pygame.draw.circle(self.screen, (10, 10, 10), ((20 - self.krug) * 50 + 25, (12 - self.krug) * 50 + 25), 25)
			self.screen.blit(self.hero_sp[self.hero_chos], (self.hero_rectx, self.hero_recty))
			self.all_sprites.draw(self.screen)
			for i in range(self.hp_kolvo):
				self.screen.blit(self.hp, (50, 50 + i * 50))
			if self.hp_kolvo == 0:
				self.running = False
			pygame.display.flip()
			self.clock.tick(60)
		pygame.quit()
		self.Rewards = Rewards(self.krug, self.hp_kolvo)
		self.Rewards.game()

	def krugy(self):
		if self.sprite.rect.x + 25 in range((20 - self.krug) * 50 - 10, (20 - self.krug) * 50 + 60) and self.sprite.rect.y + 25 in range((12 - self.krug) * 50 - 10, (12 - self.krug) * 50 + 60) and self.krug != 10 or (self.hero_rectx + 25 in range((20 - self.krug) * 50 - 10, (20 - self.krug) * 50 + 60) and self.hero_recty + 25 in range((12 - self.krug) * 50 - 10, (12 - self.krug) * 50 + 60)):
			self.hero_rectx, self.hero_recty = 10 * 50 + self.krug * 50, 2 * 50 + self.krug * 50
			if self.krug == 5:
				self.running = False
			return True


class Rewards:
	def __init__(self, krug, hp):
		self.hp = hp
		self.krug = krug
		pygame.init()
		pygame.display.set_caption('Итоги')
		self.size = width, height = 1332, 666
		self.screen = pygame.display.set_mode(self.size)
		self.end = End(self.krug, self.hp)
		self.running = True
		pygame.mouse.set_visible(False)
		self.clock = pygame.time.Clock()
		self.x, self.y, = 0, 0
		self.all_sprites = pygame.sprite.Group()
		self.sprite = pygame.sprite.Sprite()
		self.sprite.image = load_image("arrow.png", colorkey=-1)
		self.sprite.rect = self.sprite.image.get_rect()
		self.all_sprites.add(self.sprite)
		self.sprite.rect.x = 100
		self.sprite.rect.y = 100
		self.fire1, self.fire2, self.fire3 = None, None, None

	def game(self):
		while self.running:
			key = pygame.key.get_pressed()
			self.screen.fill((0, 0, 0))
			self.end.render(self.screen)
			for event in pygame.event.get():
				match event.type:
					case pygame.MOUSEMOTION:
						if pygame.mouse.get_focused():
							self.x, self.y = event.pos
					case pygame.MOUSEBUTTONDOWN:
						self.fire1, self.fire2, self.fire3 = self.end.fires(self.screen, (self.x, self.y), self.all_sprites)
					case pygame.QUIT:
						self.running = False
			self.sprite.rect.x = self.x
			self.sprite.rect.y = self.y
			if self.fire1:
				self.fire1.update()
			if self.fire2:
				self.fire2.update()
			if self.fire3:
				self.fire3.update()
			if key[pygame.K_ESCAPE]:
				self.running = False
			if self.fire1 and self.fire2 and self.fire3:
				self.end.draw_true(self.screen)
			else:
				self.end.draw(self.screen)
			self.all_sprites.draw(self.screen)
			pygame.display.flip()
			self.clock.tick(30)
		pygame.quit()


if __name__ == '__main__': 
	project = StartMenu()
	project.game()
